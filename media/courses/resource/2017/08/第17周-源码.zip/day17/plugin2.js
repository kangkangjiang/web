/**
 * Created by alex on 2016/11/26.
 */
(function (arg) {

    var status = 1;

    arg.extend({
       'wangsen': function () {
           return 'sb';
       }
    });

})(jQu$ery);
