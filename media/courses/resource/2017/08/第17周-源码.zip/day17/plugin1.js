/**
 * Created by alex on 2016/11/26.
 */


status = 1;

$.extend({
   'wangsen': function () {
       return 'sb';
   }
});